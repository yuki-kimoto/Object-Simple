package T32;
use Object::Simple;

sub m1 : Translate { target => '2->m1' }

Object::Simple->build_class;

