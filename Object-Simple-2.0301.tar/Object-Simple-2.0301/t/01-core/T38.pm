package T38;
use base 'T37';

__PACKAGE__->add_m10(k1 => 1);

1;
