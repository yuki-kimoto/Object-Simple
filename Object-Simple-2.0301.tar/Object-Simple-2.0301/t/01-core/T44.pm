package T44;
use Object::Simple(base => 'T44_Base', mixins => ['T44_Mixin']);

Object::Simple->build_class;


