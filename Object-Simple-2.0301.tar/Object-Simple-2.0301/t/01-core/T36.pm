package T36;
use Object::Simple;

sub m1 : ClassAttr { default => 1}

Object::Simple->build_class;

