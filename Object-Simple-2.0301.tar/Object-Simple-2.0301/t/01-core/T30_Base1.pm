package T30_Base1;
use Object::Simple;

sub m9 : Translate {target => 'm2->m1'}

Object::Simple->build_class;
