package T18;
use Object::Simple;

sub m1 : Attr {aaa => {}}

Object::Simple->build_class;
