package T44_Base;

sub m1 {
    my $self = shift;
    my $val = shift;
    return $val + 1;
}

1;