package T15;
use Object::Simple;

sub m1 : A {}

Object::Simple->build_class;
