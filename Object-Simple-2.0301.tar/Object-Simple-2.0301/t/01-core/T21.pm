package T21;
use Object::Simple;

sub m1 : Attr { type => 'no'}

Object::Simple->build_class;
