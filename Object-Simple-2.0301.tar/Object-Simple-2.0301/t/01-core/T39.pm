package T39;
use base 'T38';

__PACKAGE__->add_m10(k2 => 2);

1;
