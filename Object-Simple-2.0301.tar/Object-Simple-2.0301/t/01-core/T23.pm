package T23;
use Object::Simple;

sub m1 : Attr {}

Object::Simple->build_class;
