package T17;
use Object::Simple;

sub m1 : Attr {default => {}}

Object::Simple->build_class;
