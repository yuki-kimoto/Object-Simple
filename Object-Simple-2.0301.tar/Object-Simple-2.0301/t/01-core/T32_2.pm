package T32_2;
use Object::Simple;

sub m1 : Translate {}

Object::Simple->build_class;

