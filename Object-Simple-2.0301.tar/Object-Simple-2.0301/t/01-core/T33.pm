package T33;
use Object::Simple;

sub m1 : Translate { target => 'm1' }

Object::Simple->build_class;

