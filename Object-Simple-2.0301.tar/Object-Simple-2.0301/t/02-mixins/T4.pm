package T4;
use Object::Simple( base => 'nnnnnnnnnnnnnnnnnnnnnnnnnn' );

Object::Simple->build_class;
