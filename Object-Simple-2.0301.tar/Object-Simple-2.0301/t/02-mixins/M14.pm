package M14;
use Object::Simple(base => M17);

Object::Simple->build_class;
