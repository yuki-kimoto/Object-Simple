package T9;
use Object::Simple(mixins => 'M1');

Object::Simple->build_class;
