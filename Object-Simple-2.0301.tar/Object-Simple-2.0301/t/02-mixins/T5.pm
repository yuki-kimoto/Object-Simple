package T5;
use Object::Simple( base => ';;;;' );

Object::Simple->build_class;
