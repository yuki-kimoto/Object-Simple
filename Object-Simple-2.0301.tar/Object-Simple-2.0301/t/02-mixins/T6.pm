package T6;
use Object::Simple( mixins => ['nnnnnnnnnnnnnnnnnnnnnnnnn'] );

Object::Simple->build_class;
