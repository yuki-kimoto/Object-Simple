package M2;

sub m2{}

1;
