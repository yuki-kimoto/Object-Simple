package T14;
use Object::Simple(mixins => ['M15']);

Object::Simple->build_class;
