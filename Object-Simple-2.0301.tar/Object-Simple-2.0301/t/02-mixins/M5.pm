package M5;

sub m5_1{}
sub m5_2{}

1;
