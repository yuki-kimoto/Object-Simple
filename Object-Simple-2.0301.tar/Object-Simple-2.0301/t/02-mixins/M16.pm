package M16;
use Object::Simple;

sub m2 : Attr { default => 2 }

Object::Simple->build_class;
