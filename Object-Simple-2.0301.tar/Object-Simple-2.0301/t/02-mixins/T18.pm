package T18;
use Object::Simple( mixins => ['T18_Mixin1']);

Object::Simple->build_class;
