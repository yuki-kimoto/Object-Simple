package T8;
use Object::Simple(mixins => ['()()(']);

Object::Simple->build_class;
