package M1;
use Carp 'croak';

our $m2 = 1;

sub m1{}

1;
