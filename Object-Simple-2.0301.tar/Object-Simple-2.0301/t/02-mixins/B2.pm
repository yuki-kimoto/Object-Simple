package B2;
use Object::Simple;

sub m1 : Attr { default => 100};
sub m4 : Attr { default => 10};

Object::Simple->build_class;

