package M17;
use Object::Simple;

sub initialize{
    die "";
}

Object::Simple->build_class;
