package T1;
use Object::Simple( base => 'B1', mixins => ['M1'] );

Object::Simple->build_class;
