package T6;
use Object::Simple;

sub m3  : Attr {default => 3}

Object::Simple->build_class;
