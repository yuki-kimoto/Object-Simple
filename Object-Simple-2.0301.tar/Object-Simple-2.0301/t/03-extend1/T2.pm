package T2;
use base 'T1';

1;