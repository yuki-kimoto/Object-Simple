package T3;
use Object::Simple;
sub x : Attr { default => [ 1 ] }

Object::Simple->end;
