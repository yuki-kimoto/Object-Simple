package T9;
use Object::Simple;

sub m1 : Attr { required => 1 }

Object::Simple->end;
