# undef value set
package T1;
use Object::Simple;

sub a : Attr { }

Object::Simple->end;
