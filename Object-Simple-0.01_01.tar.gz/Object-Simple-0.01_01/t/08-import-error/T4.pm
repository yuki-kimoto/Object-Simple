package T4;
use Object::Simple;

sub a3 : Attr { auto_build => 1 }

Object::Simple->end;

