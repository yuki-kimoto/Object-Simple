package MyTest1;

sub p : Attr { type => 'a' }
Object::Simple->end;
