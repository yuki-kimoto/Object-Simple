package M5;
use base 'Exporter';
our @EXPORT_OK = qw/m5_2/;

sub m5_1{}
sub m5_2{}

1;
