package B1;
sub b1{};

Object::Simple->end;

