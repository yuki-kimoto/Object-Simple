package M6;
use base 'Exporter';
our %EXPORT_TAGS = ( tag1 => [ m6_1, m6_2 ] );

sub m6_1{}
sub m6_2{}
sub m6_3{}
sub m6_4{}

1;
