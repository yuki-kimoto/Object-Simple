package M2;
use base 'Exporter';
our @EXPORT = qw/m2/;

sub m2{}

1;