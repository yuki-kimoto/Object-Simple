package T4;
use Object::Simple( base => ';;;;' );

Object::Simple->end;
