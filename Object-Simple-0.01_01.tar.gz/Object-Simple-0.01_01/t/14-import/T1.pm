package T1;
use Object::Simple( base => 'B1', mixin => 'M1' );

Object::Simple->end;
