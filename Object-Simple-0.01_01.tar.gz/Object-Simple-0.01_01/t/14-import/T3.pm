package T3;
use Object::Simple( a => 'B1' );

Object::Simple->end;
