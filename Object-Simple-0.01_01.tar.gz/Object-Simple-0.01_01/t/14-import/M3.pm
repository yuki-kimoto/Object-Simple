package M3;
use base 'Exporter';

our @EXPORT = qw/m3_2 m3_4 m3_5/;
our @EXPORT_OK = qw/m3_1 m3_2/;

sub m3_1 {}
sub m3_2 {}
sub m3_3 {}

sub m3_4 {}
sub m3_5 {}

1;
