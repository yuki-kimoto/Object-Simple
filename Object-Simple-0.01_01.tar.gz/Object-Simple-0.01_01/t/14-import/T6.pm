package T6;
use Object::Simple( mixin => 'nnnnnnnnnnnnnnnnnnnnnnnnnn' );

Object::Simple->end;
