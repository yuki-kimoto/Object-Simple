package M1;
use base 'Exporter';
our @EXPORT = qw/m1/;

sub m1{}

1;
