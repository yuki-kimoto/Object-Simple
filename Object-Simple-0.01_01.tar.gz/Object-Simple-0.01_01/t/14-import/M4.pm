package M4;
use base 'Exporter';
our @EXPORT_OK = qw/m4_1 m4_2/;

sub m4_1{}
sub m4_2{}

1;