package PBook;
use Object::Simple( base => 'Book' );
Object::Simple->end;
