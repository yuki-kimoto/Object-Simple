package Book2;
use Object::Simple;

sub author : Attr { default => 2 }
Object::Simple->end;
