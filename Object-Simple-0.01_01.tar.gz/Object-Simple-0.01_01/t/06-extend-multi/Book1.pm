package Book1;
use Object::Simple;

sub title : Attr { default => 1 }
Object::Simple->end;
