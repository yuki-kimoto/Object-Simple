package Book3;
use Object::Simple( base => [ 'Book1', 'Book2' ] );

Object::Simple->end;
